document.getElementById("p2").style.color = "red";

document.write("this is how we math/ in javascript.")

var k = prompt("pick a number");
var r = prompt("pick another number");
var d = k + r;
var num1 = parseInt(k);
var num2 = parseInt(r);
var num3 = num1 +num2;
document.write("k is " + k + " r is" + r + " d is k + r ant it's " + d);
document.write("\n <br> multiplication <br>")
document.write(k * r);
document.write(k / r);
document.write("\n <br>adding: <br>")
document.write(k + r);
document.write("\n <br>subtraction <br>");
document.write(k - r);

